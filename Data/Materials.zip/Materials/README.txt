# Compound Name: Materials Project MP-ID
NiO: mp-19009
Fe2O3: mp-19770
V2O5: mp-25279
CrPbO4: mp-19146
TmNiC2: mp-4037
Sr2CuO3: mp-5456
Y2TiO5: mp-17559
CoS2: mp-2070
ZnS: mp-554820
Cr2O3: mp-19399
MnO: mp-1232659
LiMnP: mp-1176614
